<?php

/* base.html.twig */
class __TwigTemplate_4bbe4cb00ce6f8d465c8dd6727bc2b9ec28634a7580dd9013cb65806d5629e1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6bf6f2977a5277e22688625a308b8ab5bfa7d4503997871821de626599be619 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f6bf6f2977a5277e22688625a308b8ab5bfa7d4503997871821de626599be619->enter($__internal_f6bf6f2977a5277e22688625a308b8ab5bfa7d4503997871821de626599be619_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_0f94fa890f4a0fddc4c9ed79214db82de4ffba45deef71b04f7d8808bf4bb9eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f94fa890f4a0fddc4c9ed79214db82de4ffba45deef71b04f7d8808bf4bb9eb->enter($__internal_0f94fa890f4a0fddc4c9ed79214db82de4ffba45deef71b04f7d8808bf4bb9eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>

";
        // line 50
        $this->displayBlock('footer', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "
</body>
</html>
";
        
        $__internal_f6bf6f2977a5277e22688625a308b8ab5bfa7d4503997871821de626599be619->leave($__internal_f6bf6f2977a5277e22688625a308b8ab5bfa7d4503997871821de626599be619_prof);

        
        $__internal_0f94fa890f4a0fddc4c9ed79214db82de4ffba45deef71b04f7d8808bf4bb9eb->leave($__internal_0f94fa890f4a0fddc4c9ed79214db82de4ffba45deef71b04f7d8808bf4bb9eb_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_9ef2bf2c962960d82fa0b438ce454e3fcc6338214c7d9a0e618f86a78b9ed548 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ef2bf2c962960d82fa0b438ce454e3fcc6338214c7d9a0e618f86a78b9ed548->enter($__internal_9ef2bf2c962960d82fa0b438ce454e3fcc6338214c7d9a0e618f86a78b9ed548_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b00dc14823a15722bb328c66f5aec98180ec4d61e36fb9cc4f03016a3e649bd8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b00dc14823a15722bb328c66f5aec98180ec4d61e36fb9cc4f03016a3e649bd8->enter($__internal_b00dc14823a15722bb328c66f5aec98180ec4d61e36fb9cc4f03016a3e649bd8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_b00dc14823a15722bb328c66f5aec98180ec4d61e36fb9cc4f03016a3e649bd8->leave($__internal_b00dc14823a15722bb328c66f5aec98180ec4d61e36fb9cc4f03016a3e649bd8_prof);

        
        $__internal_9ef2bf2c962960d82fa0b438ce454e3fcc6338214c7d9a0e618f86a78b9ed548->leave($__internal_9ef2bf2c962960d82fa0b438ce454e3fcc6338214c7d9a0e618f86a78b9ed548_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_53fa94ba62afa5861f5743f3f926584dcfdea81f3ab1a251847380dfad2306be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_53fa94ba62afa5861f5743f3f926584dcfdea81f3ab1a251847380dfad2306be->enter($__internal_53fa94ba62afa5861f5743f3f926584dcfdea81f3ab1a251847380dfad2306be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_5e3e3aff6a34c8cabb9eb30f1f490ed129cbd032a522574b1121981d4d267db1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e3e3aff6a34c8cabb9eb30f1f490ed129cbd032a522574b1121981d4d267db1->enter($__internal_5e3e3aff6a34c8cabb9eb30f1f490ed129cbd032a522574b1121981d4d267db1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_5e3e3aff6a34c8cabb9eb30f1f490ed129cbd032a522574b1121981d4d267db1->leave($__internal_5e3e3aff6a34c8cabb9eb30f1f490ed129cbd032a522574b1121981d4d267db1_prof);

        
        $__internal_53fa94ba62afa5861f5743f3f926584dcfdea81f3ab1a251847380dfad2306be->leave($__internal_53fa94ba62afa5861f5743f3f926584dcfdea81f3ab1a251847380dfad2306be_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_b8635078c17362abe3806d047bcc3e4066d99f9afba98861b63d4ef62568e46d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8635078c17362abe3806d047bcc3e4066d99f9afba98861b63d4ef62568e46d->enter($__internal_b8635078c17362abe3806d047bcc3e4066d99f9afba98861b63d4ef62568e46d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_dba34c322113e1c00012ac2401dc7b0a985c37a9294ef7392f577e927d25a26a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dba34c322113e1c00012ac2401dc7b0a985c37a9294ef7392f577e927d25a26a->enter($__internal_dba34c322113e1c00012ac2401dc7b0a985c37a9294ef7392f577e927d25a26a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_dba34c322113e1c00012ac2401dc7b0a985c37a9294ef7392f577e927d25a26a->leave($__internal_dba34c322113e1c00012ac2401dc7b0a985c37a9294ef7392f577e927d25a26a_prof);

        
        $__internal_b8635078c17362abe3806d047bcc3e4066d99f9afba98861b63d4ef62568e46d->leave($__internal_b8635078c17362abe3806d047bcc3e4066d99f9afba98861b63d4ef62568e46d_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_d22acac0091e27ef5bf9b8622f29e08cf222aef8c9e7c75d19179161d07fd669 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d22acac0091e27ef5bf9b8622f29e08cf222aef8c9e7c75d19179161d07fd669->enter($__internal_d22acac0091e27ef5bf9b8622f29e08cf222aef8c9e7c75d19179161d07fd669_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_712a195a14211754c6f623f3cc957f5e86d3fbc7e0118fad7c45ace209fc51fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_712a195a14211754c6f623f3cc957f5e86d3fbc7e0118fad7c45ace209fc51fa->enter($__internal_712a195a14211754c6f623f3cc957f5e86d3fbc7e0118fad7c45ace209fc51fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_712a195a14211754c6f623f3cc957f5e86d3fbc7e0118fad7c45ace209fc51fa->leave($__internal_712a195a14211754c6f623f3cc957f5e86d3fbc7e0118fad7c45ace209fc51fa_prof);

        
        $__internal_d22acac0091e27ef5bf9b8622f29e08cf222aef8c9e7c75d19179161d07fd669->leave($__internal_d22acac0091e27ef5bf9b8622f29e08cf222aef8c9e7c75d19179161d07fd669_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_2ce129bb83b8b5d68477831b9cb6baadf3f1c90e69fcd831c65b407ac80af864 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2ce129bb83b8b5d68477831b9cb6baadf3f1c90e69fcd831c65b407ac80af864->enter($__internal_2ce129bb83b8b5d68477831b9cb6baadf3f1c90e69fcd831c65b407ac80af864_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_1561dc28006f93d84440e11293e1c717c2ee68577bcf7f5b09d67dd1961bf6ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1561dc28006f93d84440e11293e1c717c2ee68577bcf7f5b09d67dd1961bf6ab->enter($__internal_1561dc28006f93d84440e11293e1c717c2ee68577bcf7f5b09d67dd1961bf6ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_1561dc28006f93d84440e11293e1c717c2ee68577bcf7f5b09d67dd1961bf6ab->leave($__internal_1561dc28006f93d84440e11293e1c717c2ee68577bcf7f5b09d67dd1961bf6ab_prof);

        
        $__internal_2ce129bb83b8b5d68477831b9cb6baadf3f1c90e69fcd831c65b407ac80af864->leave($__internal_2ce129bb83b8b5d68477831b9cb6baadf3f1c90e69fcd831c65b407ac80af864_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_14cb3fcf66e764d5231121605226d7026d73a13f20981b5253184bb088bfcf8c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_14cb3fcf66e764d5231121605226d7026d73a13f20981b5253184bb088bfcf8c->enter($__internal_14cb3fcf66e764d5231121605226d7026d73a13f20981b5253184bb088bfcf8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_0a7e0c7be4a5cd0de722ba25255c29a034f77fab169ad34dec62f31b0605e2f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0a7e0c7be4a5cd0de722ba25255c29a034f77fab169ad34dec62f31b0605e2f4->enter($__internal_0a7e0c7be4a5cd0de722ba25255c29a034f77fab169ad34dec62f31b0605e2f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_0a7e0c7be4a5cd0de722ba25255c29a034f77fab169ad34dec62f31b0605e2f4->leave($__internal_0a7e0c7be4a5cd0de722ba25255c29a034f77fab169ad34dec62f31b0605e2f4_prof);

        
        $__internal_14cb3fcf66e764d5231121605226d7026d73a13f20981b5253184bb088bfcf8c->leave($__internal_14cb3fcf66e764d5231121605226d7026d73a13f20981b5253184bb088bfcf8c_prof);

    }

    // line 50
    public function block_footer($context, array $blocks = array())
    {
        $__internal_52d7bfda62fee522468b181d153d438085101438771cc926220914a79670e38c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_52d7bfda62fee522468b181d153d438085101438771cc926220914a79670e38c->enter($__internal_52d7bfda62fee522468b181d153d438085101438771cc926220914a79670e38c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_4cac950cd0725203276940595fd764ebe8b9c0ec77e81e4af1421c77a08f6a02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4cac950cd0725203276940595fd764ebe8b9c0ec77e81e4af1421c77a08f6a02->enter($__internal_4cac950cd0725203276940595fd764ebe8b9c0ec77e81e4af1421c77a08f6a02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 51
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_4cac950cd0725203276940595fd764ebe8b9c0ec77e81e4af1421c77a08f6a02->leave($__internal_4cac950cd0725203276940595fd764ebe8b9c0ec77e81e4af1421c77a08f6a02_prof);

        
        $__internal_52d7bfda62fee522468b181d153d438085101438771cc926220914a79670e38c->leave($__internal_52d7bfda62fee522468b181d153d438085101438771cc926220914a79670e38c_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_99721911a379bf4e992486dd0ec932064f14424b82554684e361f190a3ff39f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99721911a379bf4e992486dd0ec932064f14424b82554684e361f190a3ff39f8->enter($__internal_99721911a379bf4e992486dd0ec932064f14424b82554684e361f190a3ff39f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_d1aa26b4578a5bed42f7cc92d8ae392a5105ad34c1d9da450565f03f051d5c34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d1aa26b4578a5bed42f7cc92d8ae392a5105ad34c1d9da450565f03f051d5c34->enter($__internal_d1aa26b4578a5bed42f7cc92d8ae392a5105ad34c1d9da450565f03f051d5c34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 59
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_d1aa26b4578a5bed42f7cc92d8ae392a5105ad34c1d9da450565f03f051d5c34->leave($__internal_d1aa26b4578a5bed42f7cc92d8ae392a5105ad34c1d9da450565f03f051d5c34_prof);

        
        $__internal_99721911a379bf4e992486dd0ec932064f14424b82554684e361f190a3ff39f8->leave($__internal_99721911a379bf4e992486dd0ec932064f14424b82554684e361f190a3ff39f8_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 62,  275 => 61,  271 => 60,  266 => 59,  257 => 58,  242 => 51,  233 => 50,  216 => 44,  204 => 45,  202 => 44,  198 => 42,  189 => 41,  166 => 26,  160 => 22,  151 => 21,  134 => 19,  122 => 14,  117 => 13,  108 => 12,  90 => 11,  77 => 64,  75 => 58,  72 => 57,  70 => 50,  66 => 48,  64 => 41,  60 => 39,  58 => 21,  53 => 19,  46 => 16,  44 => 12,  40 => 11,  33 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
", "base.html.twig", "D:\\SoftUni\\Software Technologies\\PHP\\Calculator\\app\\Resources\\views\\base.html.twig");
    }
}
