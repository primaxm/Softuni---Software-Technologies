<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_d496044effa4cc39ce51801babe801f9942ccc5fec27a124c696ada197249fa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_10fcb1a2f745c19df185ce47d36e70cd6b406c58eacec134f6ee397563430e17 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_10fcb1a2f745c19df185ce47d36e70cd6b406c58eacec134f6ee397563430e17->enter($__internal_10fcb1a2f745c19df185ce47d36e70cd6b406c58eacec134f6ee397563430e17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_0f49499877997e1e36f8197fe4710cd3ae7ff2fec22625b806776c511705500f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f49499877997e1e36f8197fe4710cd3ae7ff2fec22625b806776c511705500f->enter($__internal_0f49499877997e1e36f8197fe4710cd3ae7ff2fec22625b806776c511705500f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_10fcb1a2f745c19df185ce47d36e70cd6b406c58eacec134f6ee397563430e17->leave($__internal_10fcb1a2f745c19df185ce47d36e70cd6b406c58eacec134f6ee397563430e17_prof);

        
        $__internal_0f49499877997e1e36f8197fe4710cd3ae7ff2fec22625b806776c511705500f->leave($__internal_0f49499877997e1e36f8197fe4710cd3ae7ff2fec22625b806776c511705500f_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_02382b2590dcc54b3eb0566d8d631da34ebe3f84b477c685aede7935eecc937f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_02382b2590dcc54b3eb0566d8d631da34ebe3f84b477c685aede7935eecc937f->enter($__internal_02382b2590dcc54b3eb0566d8d631da34ebe3f84b477c685aede7935eecc937f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_f222f2ff92d1032c4b42185f2f8750563602fd2f77cac9c303226e445be75240 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f222f2ff92d1032c4b42185f2f8750563602fd2f77cac9c303226e445be75240->enter($__internal_f222f2ff92d1032c4b42185f2f8750563602fd2f77cac9c303226e445be75240_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_f222f2ff92d1032c4b42185f2f8750563602fd2f77cac9c303226e445be75240->leave($__internal_f222f2ff92d1032c4b42185f2f8750563602fd2f77cac9c303226e445be75240_prof);

        
        $__internal_02382b2590dcc54b3eb0566d8d631da34ebe3f84b477c685aede7935eecc937f->leave($__internal_02382b2590dcc54b3eb0566d8d631da34ebe3f84b477c685aede7935eecc937f_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_df865147c5e6b22830d02a3647d1c9ff4cb59274290e2993eee916ef031ff9a3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df865147c5e6b22830d02a3647d1c9ff4cb59274290e2993eee916ef031ff9a3->enter($__internal_df865147c5e6b22830d02a3647d1c9ff4cb59274290e2993eee916ef031ff9a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_913a47fd9f865f4b7c75cabbe2484eba59d0bc809d339ce2ba538b9d55372a64 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_913a47fd9f865f4b7c75cabbe2484eba59d0bc809d339ce2ba538b9d55372a64->enter($__internal_913a47fd9f865f4b7c75cabbe2484eba59d0bc809d339ce2ba538b9d55372a64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_913a47fd9f865f4b7c75cabbe2484eba59d0bc809d339ce2ba538b9d55372a64->leave($__internal_913a47fd9f865f4b7c75cabbe2484eba59d0bc809d339ce2ba538b9d55372a64_prof);

        
        $__internal_df865147c5e6b22830d02a3647d1c9ff4cb59274290e2993eee916ef031ff9a3->leave($__internal_df865147c5e6b22830d02a3647d1c9ff4cb59274290e2993eee916ef031ff9a3_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_09a55df44567762858aa715ad163fc7a69fd18e13a25d03fc55a51c801261b45 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_09a55df44567762858aa715ad163fc7a69fd18e13a25d03fc55a51c801261b45->enter($__internal_09a55df44567762858aa715ad163fc7a69fd18e13a25d03fc55a51c801261b45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_c072ce8428945c363b09e240963f5dcdaee278ffe6669dda8867c2b1f058be24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c072ce8428945c363b09e240963f5dcdaee278ffe6669dda8867c2b1f058be24->enter($__internal_c072ce8428945c363b09e240963f5dcdaee278ffe6669dda8867c2b1f058be24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_c072ce8428945c363b09e240963f5dcdaee278ffe6669dda8867c2b1f058be24->leave($__internal_c072ce8428945c363b09e240963f5dcdaee278ffe6669dda8867c2b1f058be24_prof);

        
        $__internal_09a55df44567762858aa715ad163fc7a69fd18e13a25d03fc55a51c801261b45->leave($__internal_09a55df44567762858aa715ad163fc7a69fd18e13a25d03fc55a51c801261b45_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "D:\\SoftUni\\Software Technologies\\PHP\\Calculator\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
