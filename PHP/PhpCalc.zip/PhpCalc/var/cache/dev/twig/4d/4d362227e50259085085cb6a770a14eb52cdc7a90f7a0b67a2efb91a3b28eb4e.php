<?php

/* @Security/Collector/icon.svg */
class __TwigTemplate_984be46ae8724bb079e8cfba8d3a2c0a1e92d336020b97c2cbb6a66935090dcb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f43d11ab8135406359e8d296bae9911d229f171b738d22c56c96cf526b7c5e99 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f43d11ab8135406359e8d296bae9911d229f171b738d22c56c96cf526b7c5e99->enter($__internal_f43d11ab8135406359e8d296bae9911d229f171b738d22c56c96cf526b7c5e99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Security/Collector/icon.svg"));

        $__internal_80ed30e8f83cd10b07b6d83984f85f9f396d20b0cb796ebcbc060e2735cf50e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80ed30e8f83cd10b07b6d83984f85f9f396d20b0cb796ebcbc060e2735cf50e9->enter($__internal_80ed30e8f83cd10b07b6d83984f85f9f396d20b0cb796ebcbc060e2735cf50e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Security/Collector/icon.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"M21,20.4V22H3v-1.6c0-3.7,2.4-6.9,5.8-8c-1.7-1.1-2.9-3-2.9-5.2c0-3.4,2.7-6.1,6.1-6.1s6.1,2.7,6.1,6.1c0,2.2-1.2,4.1-2.9,5.2C18.6,13.5,21,16.7,21,20.4z\"/>
</svg>
";
        
        $__internal_f43d11ab8135406359e8d296bae9911d229f171b738d22c56c96cf526b7c5e99->leave($__internal_f43d11ab8135406359e8d296bae9911d229f171b738d22c56c96cf526b7c5e99_prof);

        
        $__internal_80ed30e8f83cd10b07b6d83984f85f9f396d20b0cb796ebcbc060e2735cf50e9->leave($__internal_80ed30e8f83cd10b07b6d83984f85f9f396d20b0cb796ebcbc060e2735cf50e9_prof);

    }

    public function getTemplateName()
    {
        return "@Security/Collector/icon.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"M21,20.4V22H3v-1.6c0-3.7,2.4-6.9,5.8-8c-1.7-1.1-2.9-3-2.9-5.2c0-3.4,2.7-6.1,6.1-6.1s6.1,2.7,6.1,6.1c0,2.2-1.2,4.1-2.9,5.2C18.6,13.5,21,16.7,21,20.4z\"/>
</svg>
", "@Security/Collector/icon.svg", "D:\\SoftUni\\Software Technologies\\PHP\\Calculator\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\SecurityBundle\\Resources\\views\\Collector\\icon.svg");
    }
}
