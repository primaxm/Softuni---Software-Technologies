<?php

/* @Twig/images/icon-minus-square.svg */
class __TwigTemplate_aa5a24b3497084b962a9674e1785286a307ca518a71052cd1b21188a2d716262 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_45383f8abdd6cfd266febe1495eab3cd20ed2cf5cc0e4781b3ddcc66f765cddc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_45383f8abdd6cfd266febe1495eab3cd20ed2cf5cc0e4781b3ddcc66f765cddc->enter($__internal_45383f8abdd6cfd266febe1495eab3cd20ed2cf5cc0e4781b3ddcc66f765cddc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        $__internal_8f1a70b3465282b8a42635c3527df80062ceb64421c01026aefef90547dc14a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f1a70b3465282b8a42635c3527df80062ceb64421c01026aefef90547dc14a9->enter($__internal_8f1a70b3465282b8a42635c3527df80062ceb64421c01026aefef90547dc14a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
";
        
        $__internal_45383f8abdd6cfd266febe1495eab3cd20ed2cf5cc0e4781b3ddcc66f765cddc->leave($__internal_45383f8abdd6cfd266febe1495eab3cd20ed2cf5cc0e4781b3ddcc66f765cddc_prof);

        
        $__internal_8f1a70b3465282b8a42635c3527df80062ceb64421c01026aefef90547dc14a9->leave($__internal_8f1a70b3465282b8a42635c3527df80062ceb64421c01026aefef90547dc14a9_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-minus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
", "@Twig/images/icon-minus-square.svg", "D:\\SoftUni\\Software Technologies\\PHP\\Calculator\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\images\\icon-minus-square.svg");
    }
}
